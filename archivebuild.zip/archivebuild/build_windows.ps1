# build_windows.ps1 — run in Developer Command Prompt or PowerShell with MSVC tools
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "Building OASM (Windows) in $root"
nasm -D WINDOWS -f win64 -I "$root\oasm" "$root\src_unified.asm" -o "$root\obj.obj"
# Link with kernel32.lib (assumes Visual Studio dev tools in PATH)
link /NOLOGO "$root\obj.obj" kernel32.lib /OUT:"$root\oasm_unified.exe"
Write-Host "Running oasm_unified.exe..."
& "$root\oasm_unified.exe"
Write-Host "Finished."
