#!/usr/bin/env bash
set -e
ROOT="$(pwd)"
echo "Building OASM (WSL/Linux) in $ROOT"
nasm -D LINUX -f elf64 -I ./oasm src_unified.asm -o obj.o
gcc obj.o -o oasm_unified
echo "Running oasm_unified..."
./oasm_unified
echo "Finished."
