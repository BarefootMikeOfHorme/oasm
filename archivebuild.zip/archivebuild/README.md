# OASM Project

Project root: C:\Users\Administrator\Desktop\Projects\oasm

Folders:
- oasm/    : macro packs and includes
- src_unified.asm : unified entry source
- build_wsl.sh    : WSL build script
- build_windows.ps1 : Windows build script

To build:
- WSL/Linux: run ./build_wsl.sh
- Windows: open Developer Command Prompt and run build_windows.ps1

Files created by this script are intended as a production-ready foundation. Edit the .inc packs to extend functionality.
